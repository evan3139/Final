# Author
Evan Wildenhain & John Sullivan
4/17/18

## About
 This program will detect a language that a file is written in. It will read files and train off of those files so it can then detect what language future files are written in.
